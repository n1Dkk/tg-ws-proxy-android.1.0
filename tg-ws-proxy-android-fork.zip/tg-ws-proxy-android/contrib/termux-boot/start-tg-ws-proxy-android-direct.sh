#!/data/data/com.termux/files/usr/bin/sh
mkdir -p "$HOME/.config/tg-ws-proxy-android"
termux-wake-lock >/dev/null 2>&1 || true
nohup tg-ws-proxy-android start >>"$HOME/.config/tg-ws-proxy-android/boot.log" 2>&1 &
