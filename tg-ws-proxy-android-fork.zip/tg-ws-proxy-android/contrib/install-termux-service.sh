#!/data/data/com.termux/files/usr/bin/sh
set -eu

SERVICE_NAME="tg-ws-proxy-android"
SOURCE_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)/termux-services/$SERVICE_NAME"
TARGET_DIR="$PREFIX/var/service/$SERVICE_NAME"

mkdir -p "$TARGET_DIR" "$TARGET_DIR/log"
cp "$SOURCE_DIR/run" "$TARGET_DIR/run"
chmod +x "$TARGET_DIR/run"

if [ -x "$PREFIX/share/termux-services/svlogger" ]; then
  ln -sf "$PREFIX/share/termux-services/svlogger" "$TARGET_DIR/log/run"
fi

echo "Installed service to: $TARGET_DIR"
echo "Start with: sv up $SERVICE_NAME"
echo "Logs: $PREFIX/var/log/sv/$SERVICE_NAME/current"
