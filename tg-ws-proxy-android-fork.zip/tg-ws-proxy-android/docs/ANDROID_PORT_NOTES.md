# Android port notes

## Что поменялось относительно upstream

### 1. Убрана desktop-first упаковка

В оригинале основное удобство построено вокруг:

- `windows.py`
- `linux.py`
- `macos.py`
- tray-иконки
- GUI-настроек
- desktop deep-link flow

Для Android это почти всё лишнее.

### 2. Добавлен launcher `android.py`

Он решает Android-специфичные задачи:

- хранит конфиг в `~/.config/tg-ws-proxy-android/`
- ведёт rotating log
- умеет вызвать `termux-wake-lock`
- умеет открыть `tg://socks?...` или `https://t.me/socks?...`
- оставляет ядро прокси нетронутым

### 3. Переименованы описания в ядре

`Telegram Desktop` -> `Telegram client`

То есть лог теперь не врёт, когда прокси запускается под Android.

### 4. Упрощён `pyproject.toml`

Сборка теперь ориентирована на:

- пакет `tg-ws-proxy-android`
- entry point `tg-ws-proxy-android = android:main`
- отсутствие обязательных GUI/tray-зависимостей

## Что я сознательно НЕ делал

- не делал APK через Kivy / Buildozer;
- не переписывал сервис на Kotlin/Java;
- не добавлял VpnService / tun-mode;
- не трогал сетевое ядро без реальной Android runtime-проверки.

## Почему не трогал сетевое ядро

`proxy/tg_ws_proxy.py` уже содержит mobile-aware ветку: если у мобильного клиента `dc_id` в init-пакете не определяется, код пытается восстановить его по известным Telegram IP и патчит init packet перед отправкой.

Именно поэтому лучший Android-fork здесь — это новая оболочка, а не агрессивный рефактор ядра.
