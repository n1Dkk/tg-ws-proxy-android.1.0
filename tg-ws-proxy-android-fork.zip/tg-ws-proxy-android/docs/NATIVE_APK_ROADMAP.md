# Native APK roadmap

Если делать **не Termux fork**, а именно APK, я бы раскладывал работу так.

## Архитектура

### Вариант A — Kotlin service + Python core as embedded runtime

Плюсы:

- можно переиспользовать текущее ядро;
- быстрее MVP.

Минусы:

- сложная упаковка Python в APK;
- тяжелее обновления и отладка;
- нужно аккуратно решать ABI / arm64 / x86_64.

### Вариант B — переписать launcher/service часть на Kotlin, а потом при необходимости и ядро

Плюсы:

- нормальная интеграция с Android lifecycle;
- foreground service, notification, battery policy;
- проще выпускать APK.

Минусы:

- больше работы.

## Что обязательно нужно в APK

1. **ForegroundService** с постоянной notification.
2. Локальный TCP listener на `127.0.0.1:1080`.
3. Экран настроек:
   - host
   - port
   - dc_ip overrides
   - verbose
   - start on boot
4. `BOOT_COMPLETED` receiver.
5. Кнопка `Open in Telegram` через `tg://socks?...`.
6. Логи внутри app storage + экспорт логов.
7. Обработка battery optimization и инструкции пользователю.

## Что ещё стоит сделать

- healthcheck локального сокета;
- статус-экран с counters из `_stats`;
- one-tap copy/manual proxy instructions;
- optional self-test against known Telegram DC.

## Что не стоит обещать заранее

- стабильную работу calls через один только SOCKS5 path;
- беспроблемный background на всех OEM-прошивках;
- одинаковое поведение на всех Telegram forks.
